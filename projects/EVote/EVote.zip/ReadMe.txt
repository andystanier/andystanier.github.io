EVote is a desktop Java application which can be used to create and run elections for upto eight candidates.  The results will be counted and uploaded to a website which can be viewed once the election is complete.

Running EVote


To run EVote:
1.	Ensure you are connected to the University of Hertfordshire's servers either by location or VPN. Details on how to do this are available on the UoH website.
2.	Make sure you are using Java 8.
3.	In Windows, once unzipped, in the EVote folder, locate and run EVote.jar by double clicking.
4.	In Linux, in the EVote folder, locate and run EVote.jar using the terminal command 'java -jar EVote.jar'.



Andy Stanier, September 2016
